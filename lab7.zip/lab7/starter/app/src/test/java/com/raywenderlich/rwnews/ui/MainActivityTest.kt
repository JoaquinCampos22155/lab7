package com.raywenderlich.rwnews.ui

import org.junit.Assert.*

class MainActivityTest